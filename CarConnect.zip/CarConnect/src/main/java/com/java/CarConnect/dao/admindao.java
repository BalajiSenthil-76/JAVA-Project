package com.java.CarConnect.dao;

import java.sql.SQLException;

import java.util.List;

import com.java.CarConnect.exception.AdminNotFoundException;
import com.java.CarConnect.model.Admin;



public interface admindao {
	List<Admin> Showadmin() throws SQLException, ClassNotFoundException;
	Admin GetAdminById(int adminID) throws SQLException, ClassNotFoundException, AdminNotFoundException;
	Admin GetAdminByUsername(String username) throws ClassNotFoundException, SQLException;
	int authenticateAdmin(String user,String pwd) throws ClassNotFoundException, SQLException;
	Admin  UpdateAdmin(Admin admin4) throws ClassNotFoundException, SQLException;
	String  DeleteAdmin(int adminID ) throws ClassNotFoundException, SQLException, AdminNotFoundException;
}
