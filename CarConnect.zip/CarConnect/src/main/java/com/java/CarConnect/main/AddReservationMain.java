

package com.java.CarConnect.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.sql.*;
import com.java.CarConnect.dao.IReservationService;

import com.java.CarConnect.dao.ReservationService;
import com.java.CarConnect.model.Reservation;
import com.java.CarConnect.exception.DatabaseConnectionException;
import com.java.CarConnect.exception.InvalidInputException;
import com.java.CarConnect.exception.ReservationException;

import java.sql.Date;
public class AddReservationMain {
	public static void main(String[] args) throws ReservationException, InvalidInputException, DatabaseConnectionException
	{
		IReservationService i=new ReservationService();
		ReservationService i1=new ReservationService();
		Reservation r=new Reservation();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter reservation Id");
		
	
		int reservationId=s.nextInt();
		
		r.setReservationId(reservationId);
		System.out.println("Enter customerId Id");
		
		
		int customerIdId=s.nextInt();
		r.setCustomerId(customerIdId);
		System.out.println("Enter vehicleId Id");
		
		
		int vehicleId=s.nextInt();
		
		boolean x;
		try {
			x = i1.vehicle(vehicleId);
			if(x)
			{
				ReservationException rc=new ReservationException("Vehicle already reserved");
				throw rc;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			throw new DatabaseConnectionException("Issue with connectivity or sql query has error");
		}
		
	
		r.setVehicleId(vehicleId);
		s.nextLine();
		System.out.println("Enter startDate");
		String d=s.nextLine();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
			java.util.Date date = dateFormat.parse(d);
			 if (date.after(Calendar.getInstance().getTime())) {
                 throw new InvalidInputException("Date Invalid.");
             }

			 java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			 r.setStartDate(sqlDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
		throw new InvalidInputException("Enter date in correct format yyyy-mm-dd");
		}
		System.out.println("Enter endDate");
		String d1=s.nextLine();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        try {
			java.util.Date date = dateFormat1.parse(d1);
			if (date.after(Calendar.getInstance().getTime())) {
                throw new InvalidInputException("Date Invalid.");
            }

			 java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			 r.setEndDate(sqlDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			throw new InvalidInputException("Enter date in correct format yyyy-mm-dd");

		}
		
		
		
	
		int cost;
		try {
			cost = i1.getVehicleCost(vehicleId);
		int days=i1.dateDiff(r.getStartDate(),r.getEndDate());
		r.calculateTotalCost(days, cost);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	try {
		String str=i.createReservation(r);
		System.out.println(str);
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
		
		
		
		
	}

}

