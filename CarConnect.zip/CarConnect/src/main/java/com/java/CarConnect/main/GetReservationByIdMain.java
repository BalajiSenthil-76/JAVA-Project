
package com.java.CarConnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarConnect.dao.IReservationService;

import com.java.CarConnect.dao.ReservationService;
import com.java.CarConnect.exception.DatabaseConnectionException;
import com.java.CarConnect.model.Reservation;

public class GetReservationByIdMain {
	public static void main(String[] args) throws DatabaseConnectionException
	{

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter reservation id");
		int i=sc.nextInt();
		IReservationService ic=new ReservationService();
		Reservation r;
		try {
			r= ic.getReservationById(i);
			System.out.println(r);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseConnectionException("Issue with connectivity or wrong sql query");
		}

		
		
	}

	
}

