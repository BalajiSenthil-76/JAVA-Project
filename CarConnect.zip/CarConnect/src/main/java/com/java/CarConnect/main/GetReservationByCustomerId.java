

package com.java.CarConnect.main;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.java.CarConnect.dao.IReservationService;

import com.java.CarConnect.dao.ReservationService;
import com.java.CarConnect.exception.DatabaseConnectionException;
import com.java.CarConnect.model.Reservation;

public class GetReservationByCustomerId {
	public static void main(String[] args) throws DatabaseConnectionException
	{

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter customerId id");
		int i=sc.nextInt();
		IReservationService ic=new ReservationService();
		List<Reservation> r=new ArrayList<>();
		try {
			r= ic.getReservationByCustomerId(i);
			if(r.size()==0)
			{
				System.out.println("Customer hasn't done any reservation");
			}
			else
			{
				System.out.println("Total number of reservation customer made : " + r.size());
				for(i=0;i<r.size();i++)
				{
					System.out.println(r.get(i));
				}
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseConnectionException("Issue with connectivity or wrong sql query");
		}

		
		
	}

}


