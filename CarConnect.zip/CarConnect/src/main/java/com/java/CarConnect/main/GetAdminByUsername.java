package com.java.CarConnect.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.CarConnect.dao.Admindaoimpl;
import com.java.CarConnect.dao.admindao;
import com.java.CarConnect.exception.AdminNotFoundException;
import com.java.CarConnect.exception.InvalidInputException;
import com.java.CarConnect.model.Admin;

public class GetAdminByUsername {
	public static void main(String[] args) throws AdminNotFoundException {
		 String username;
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the Username:");
		username=sc.next();
		
		try {
            validateUsername(username);
        } catch (InvalidInputException e) {
            System.err.println("Invalid input: " + e.getMessage());
            return;
        }
		
		admindao  dao=new Admindaoimpl();
		 try {
			Admin admin2=dao.GetAdminByUsername(username);
			if(admin2 !=null)
				System.out.println(admin2);
			else
				System.out.println("**Username not found");
		} 
		 catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private static void validateUsername(String username) throws InvalidInputException {
        if (username.matches("\\d+")||username.contains(" ")||username.startsWith("_", 0)) 
            throw new InvalidInputException("you are giving non supported format .Please enter a valid Username.");
        }
	}

