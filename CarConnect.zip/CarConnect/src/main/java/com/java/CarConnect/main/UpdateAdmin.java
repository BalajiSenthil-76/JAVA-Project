package com.java.CarConnect.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.CarConnect.dao.Admindaoimpl;
import com.java.CarConnect.dao.admindao;
import com.java.CarConnect.exception.AdminNotFoundException;
import com.java.CarConnect.model.Admin;

public class UpdateAdmin {
public static void main(String[] args) throws ClassNotFoundException, SQLException, AdminNotFoundException {
	int adminID;
	String firstname,lastname,email,phone,username,password,role,joinDate;
	Scanner sc=new Scanner (System.in);
	
	Admin admin4=new Admin();
	
	System.out.println("Enter the AdminID to  be updated");
	adminID=sc.nextInt();
	
	admin4.setAdminID(adminID);
	
	Admindaoimpl dao=new Admindaoimpl();
	Admin validAdmin = dao.GetAdminById(adminID);
	
	if(validAdmin==null)
	{
		System.out.println("Enter a Valid AdminID");
		}
	else
	System.out.println(dao.GetAdminById(adminID));
	

	System.out.println("Enter Firstname:");
	admin4.setFirstname(sc.next());
	System.out.println("Enter Lastname:");
	admin4.setLastname(sc.next());
	System.out.println("Enter Email:");
	admin4.setEmail(sc.next());
	System.out.println("Enter PhoneNumber:");
	admin4.setPhone(sc.next());
	System.out.println("Enter Username:");
	admin4.setUsername(sc.next());
	System.out.println("Enter Password:");
	admin4.setPassword(sc.next());
	System.out.println("Enter Role:");
	admin4.setRole(sc.next());
	System.out.println("Enter JoiningDate:");
	admin4.setJoinDate(sc.next());

	
	try {
		dao.UpdateAdmin(admin4);
		
	System.out.println(dao.UpdateAdmin(admin4));
	System.out.println("Admin details are updated Successfully");
	System.out.println(dao.Showadmin());
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}
