package com.java.CarConnect.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import com.java.CarConnect.exception.InvalidInputException;
import com.java.CarConnect.dao.CustomerService;
import com.java.CarConnect.model.Customer;

public class AddCustomer {
	
	public static void main(String[] args) {
		Customer customer = new Customer();
		Scanner sc = new Scanner(System.in);
		
		CustomerService customerService = new CustomerService();
				
		System.out.println("Enter Customer Id : ");
		int customerId = sc.nextInt();
		
		customer.setCustomerId(customerId);
		sc.nextLine();
		
		try {
			Customer isValidCustomer = customerService.getCustomerById(customerId);
			
			if(isValidCustomer!=null)
			{
				System.out.println("Customer Id already exists.");
			}
			else
			{
				System.out.println("Enter First Name : ");
				String firstName = sc.nextLine();
				 if (firstName.isEmpty()) {
					 InvalidInputException iie = new InvalidInputException("First Name cannot be empty.");
			        	throw iie ; 
				 }
				 else {
					 customer.setFirstName(firstName);
				 }
				
				System.out.println("Enter Last Name : ");
				String lastName = sc.nextLine();
				 if (lastName.isEmpty()) {
					 InvalidInputException iie = new InvalidInputException("Last Name cannot be empty.");
			        	throw iie ; 
				 }
				 else {
					 customer.setLastName(lastName);
				 }
				System.out.println("Enter Email : ");
				customer.setEmail(sc.nextLine());
				
				System.out.println("Enter Phone No : ");
				customer.setPhoneNumber(sc.nextLine());
				
				System.out.println("Enter Address : ");
				customer.setAddress(sc.nextLine());
				
				System.out.println("Enter UserName : ");
				String username = sc.nextLine();
				 if (username.isEmpty()) {
					 InvalidInputException iie = new InvalidInputException("Username cannot be empty.");
			        	throw iie ; 
				 }
				 else {
					 customer.setUserName(username);
				 }
				
				System.out.println("Enter Password : ");
				String password = sc.nextLine();
				 if (password.isEmpty()) {
					 InvalidInputException iie = new InvalidInputException("Password cannot be empty.");
			        	throw iie ; 
				 }
				 else
				 {
					 customer.setPassword(password);
				 }
				
				System.out.println("Enter Registration Date in (yyyy-mm-dd) format : ");
				String dateString = sc.nextLine();
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    java.util.Date date = dateFormat.parse(dateString);
                    
                    // Validate the date is not ahead of the current date
                    if (date.after(Calendar.getInstance().getTime())) {
                        throw new InvalidInputException("Registration date Invalid.");
                    }
                    
                    java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                    customer.setRegistrationDate(sqlDate);
                } catch (ParseException e) {
                    throw new InvalidInputException("Invalid date format. Please enter date in yyyy-mm-dd format.");
                }
                    
                try {
                    String message = customerService.registerCustomer(customer);
                    System.out.println(message);
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (InvalidInputException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

	}
	
}