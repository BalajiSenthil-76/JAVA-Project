package com.java.CarConnect.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.java.CarConnect.model.Reservation;
import com.java.CarConnect.util.DBConnUtil;
import com.java.CarConnect.util.DBPropertyUtil;

public class ReservationService implements IReservationService {
Connection connection;
PreparedStatement pst;

	@Override
	public String createReservation(Reservation r) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "INSERT INTO Reservation (ReservationID, CustomerID, VehicleID, StartDate, EndDate, TotalCost, Status)\r\n"
				+ "VALUES (?,?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1,r.getReservationId());
		pst.setInt(2,r.getCustomerId());
		pst.setInt(3,r.getVehicleId());
		pst.setDate(4,r.getStartDate());
		pst.setDate(5,r.getEndDate());
		pst.setInt(6,r.getTotalCost());
		pst.setString(7,"pending");
		pst.executeUpdate();
return "Reservation record inserted";

		
		
		
	}

	@Override
	public String cancelReservation(int reservationId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="delete from reservation where reservationId=?";
		pst = connection.prepareStatement(query);
		pst.setInt(1, reservationId);

		pst.executeUpdate();
		
		return "Reservation Record Deleted";
				
	}

	@Override
	public String updateReservation(int id,String status) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="update reservation set status=? where reservationId=?";
		pst = connection.prepareStatement(query);
		pst.setInt(2, id);
		pst.setString(1,status);

		pst.executeUpdate();
		
		return "Reservation Record Updated";
	}

	@Override
	public Reservation getReservationById(int id) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="select * from reservation where reservationId=?";
		pst = connection.prepareStatement(query);
		
		pst.setInt(1,id);

		ResultSet rs=pst.executeQuery();
		Reservation r=new Reservation();
		while(rs.next())
		{
			r.setReservationId(rs.getInt("reservationId"));
			r.setVehicleId(rs.getInt("vehicleId"));
r.setCustomerId(rs.getInt("customerId"));
r.setStartDate(rs.getDate("startDate"));
r.setEndDate(rs.getDate("endDate"));
r.setTotalCost(rs.getInt("totalCost"));
r.setStatus1(rs.getString("status"));


		}
		return r;
		
		
	}

	@Override
	public List<Reservation> getReservationByCustomerId(int customerId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		List<Reservation> l=new ArrayList<>();
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="select * from reservation where customerId=?";
		pst = connection.prepareStatement(query);
		
		pst.setInt(1,customerId);

		ResultSet rs=pst.executeQuery();
		
		while(rs.next())
		{
			Reservation r=new Reservation();
			r.setReservationId(rs.getInt("reservationId"));
			r.setVehicleId(rs.getInt("vehicleId"));
r.setCustomerId(rs.getInt("customerId"));
r.setStartDate(rs.getDate("startDate"));
r.setEndDate(rs.getDate("endDate"));
r.setTotalCost(rs.getInt("totalCost"));
r.setStatus1(rs.getString("status"));

l.add(r);

		}
		return l;
	}
	public boolean vehicle(int id) throws SQLException,ClassNotFoundException
	{
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="select * from reservation where vehicleId=?";
		pst = connection.prepareStatement(query);
		
		pst.setInt(1,id);
		ResultSet rs=pst.executeQuery();
		if(rs.next())
		return true;
		else
			return false;
	}
	public int getVehicleCost(int vehicleId) throws SQLException,ClassNotFoundException
	{
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="select dailyRate from vehicle where vehicleId=?";
		pst = connection.prepareStatement(query);
		
		pst.setInt(1,vehicleId);
		int cost=0;
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			cost=rs.getInt("dailyRate");
		}
		return cost;
	}
	public int dateDiff(Date startDate,Date endDate) throws SQLException,ClassNotFoundException
	{
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String query="select dateDiff(?,?) as date";
		pst = connection.prepareStatement(query);
pst.setDate(1,endDate);
pst.setDate(2, startDate);
ResultSet rs=pst.executeQuery();
int days=0;
while(rs.next())
{
	days=rs.getInt("date");
}
return days;
	}
	

	

	

	
}

