package com.java.CarConnect.exception;

public class ReservationException extends Exception {
public ReservationException(String message)
{
	super(message);
}

}
