package com.java.CarConnect.model;

public enum Status {
pending,confirmed,completed;
}