package com.java.CarConnect.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.java.CarConnect.dao.CustomerService;
import com.java.CarConnect.dao.ICustomerService;
import com.java.CarConnect.model.Customer;

public class UpdateCustomer {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Customer customer = new Customer();
		
		System.out.println("Enter Cutomer Id : ");
		int customerId = sc.nextInt();
		sc.nextLine();
		
		customer.setCustomerId(customerId);
		
		ICustomerService customerService = new CustomerService();
		try {
			Customer isValidCustomer = customerService.getCustomerById(customerId);
			if(isValidCustomer==null)
			{
				System.out.println("No Matching record exists to Update.");
			}
			else
			{
				System.out.println("Enter First Name : ");
				customer.setFirstName(sc.nextLine());
				
				System.out.println("Enter Last Name : ");
				customer.setLastName(sc.nextLine());
				
				System.out.println("Enter Email : ");
				customer.setEmail(sc.nextLine());
				
				System.out.println("Enter Phone Number : ");
				customer.setPhoneNumber(sc.nextLine());
				
				System.out.println("Enter Address : ");
				customer.setAddress(sc.nextLine());
				
				System.out.println("Enter Username : ");
				customer.setUserName(sc.nextLine());
				
				System.out.println("Enter Password : ");
				customer.setPassword(sc.nextLine());
				
				System.out.println("Enter Registration Date in (yyyy-mm-dd) format : ");
				String dateString = sc.nextLine();
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		        try {
					java.util.Date date = dateFormat.parse(dateString);
					 java.sql.Date sqlDate = new java.sql.Date(date.getTime());
					  customer.setRegistrationDate(sqlDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        
		  
		        try {
					String message = customerService.updateCustomer(customer);
					
					System.out.println(message);
					
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
