package com.java.CarConnect.model;

import java.sql.Date;

public class Reservation {
private int reservationId;
private int customerId;
private int vehicleId;
private int totalCost;
private Status status;
private java.sql.Date startDate;
private java.sql.Date endDate;
private String status1;
public int getReservationId() {
	return reservationId;
}
public Reservation(int reservationId, int customerId, int vehicleId, int totalCost, Status status, Date startDate,
		Date endDate) {
	super();
	this.reservationId = reservationId;
	this.customerId = customerId;
	this.vehicleId = vehicleId;
	this.totalCost = totalCost;
	this.status = status;
	this.startDate = startDate;
	this.endDate = endDate;
}
public Reservation()
{
	
}
public Status getStatus() {
	return status;
}

public void calculateTotalCost(int days,int cost)
{
	this.totalCost=days*cost;
	this.setTotalCost(totalCost);
}
public void setReservationId(int reservationId) {
	this.reservationId = reservationId;
}
@Override
public String toString() {
	return "Reservation [reservationId=" + reservationId + ", customerId=" + customerId + ", vehicleId=" + vehicleId
			+ ", totalCost=" + totalCost + ", startDate=" + startDate + ", endDate=" + endDate + ", status=" + status1
			+ "]";
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public int getVehicleId() {
	return vehicleId;
}
public void setVehicleId(int vehicleId) {
	this.vehicleId = vehicleId;
}
public int getTotalCost() {
	return totalCost;
}
public void setTotalCost(int totalCost) {
	this.totalCost = totalCost;
}
public java.sql.Date getStartDate() {
	return startDate;
}
public void setStartDate(java.sql.Date startDate) {
	this.startDate = startDate;
}
public String getStatus1() {
	return status1;
}
public void setStatus1(String status1) {
	this.status1 = status1;
}
public java.sql.Date getEndDate() {
	return endDate;
}
public void setEndDate(java.sql.Date endDate) {
	this.endDate = endDate;
}



}

