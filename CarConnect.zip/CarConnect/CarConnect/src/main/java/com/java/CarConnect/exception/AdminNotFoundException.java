package com.java.CarConnect.exception;

public class AdminNotFoundException extends Exception{
	public AdminNotFoundException(String message) {
        super(message);
    }

}
