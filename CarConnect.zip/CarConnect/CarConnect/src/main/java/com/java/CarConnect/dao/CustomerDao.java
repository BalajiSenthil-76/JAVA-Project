package com.java.CarConnect.dao;

import java.sql.SQLException;
import java.util.List;
import com.java.CarConnect.model.Customer;


public interface CustomerDao {
		List<Customer> showCustomerDao() throws ClassNotFoundException, SQLException;
}
