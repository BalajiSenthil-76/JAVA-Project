package com.java.CarConnect.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.CarConnect.dao.IReservationService;
import com.java.CarConnect.dao.ReservationService;
import com.java.CarConnect.model.Customer;


public class DeleteReservationMain {
public static void main(String[] args)
{

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter reservation id");
	int i=sc.nextInt();
	IReservationService ic=new ReservationService();
	String str;
	try {
		str = ic.cancelReservation(i);
		System.out.println(str);
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
	
}
}
