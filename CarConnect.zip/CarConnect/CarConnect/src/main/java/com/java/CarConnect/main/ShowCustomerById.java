package com.java.CarConnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarConnect.dao.CustomerService;
import com.java.CarConnect.dao.ICustomerService;
import com.java.CarConnect.model.Customer;

public class ShowCustomerById {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Customer Id : ");
		int customerId = sc.nextInt();
		
		ICustomerService customerService = new CustomerService();
		
		try {
			Customer customer = customerService.getCustomerById(customerId);
			
			if(customer!=null)
			{
				System.out.println(customer);
			}
			else
			{
				System.out.println("No matching Record Found.");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
