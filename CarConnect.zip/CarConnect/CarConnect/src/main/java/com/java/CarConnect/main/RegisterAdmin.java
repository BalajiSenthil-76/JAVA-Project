package com.java.CarConnect.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.CarConnect.dao.Admindaoimpl;
import com.java.CarConnect.model.Admin;

public class RegisterAdmin {
public static void main(String[] args) throws ClassNotFoundException, SQLException 
{
	Admin admin3=new Admin();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Admin ID");
	admin3.setAdminID(sc.nextInt());
	System.out.println("Enter Firstname:");
	admin3.setFirstname(sc.next());
	System.out.println("Enter Lastname:");
	admin3.setLastname(sc.next());
	System.out.println("Enter Email:");
	admin3.setEmail(sc.next());
	System.out.println("Enter PhoneNumber:");
	admin3.setPhone(sc.next());
	System.out.println("Enter Username:");
	admin3.setUsername(sc.next());
	System.out.println("Enter Password:");
	admin3.setPassword(sc.next());
	System.out.println("Enter Role:");
	admin3.setRole(sc.next());
	System.out.println("Enter JoiningDate:");
	admin3.setJoinDate(sc.next());
	Admindaoimpl dao=new Admindaoimpl();
	System.out.println(dao.RegisterAdmin(admin3));
	
}


}
