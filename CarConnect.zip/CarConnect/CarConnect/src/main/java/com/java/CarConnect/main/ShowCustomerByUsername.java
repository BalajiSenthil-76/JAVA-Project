package com.java.CarConnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarConnect.dao.CustomerService;
import com.java.CarConnect.dao.ICustomerService;
import com.java.CarConnect.model.Customer;

public class ShowCustomerByUsername {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Username : ");
		String username = sc.next();
		
		ICustomerService customerService = new CustomerService();
		
		try {
			Customer customer = customerService.getCustomerByUsername(username);
			
			if(customer!=null)
			{
				System.out.println(customer);
			}
			else
			{
				System.out.println("No matching Record Found.");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
