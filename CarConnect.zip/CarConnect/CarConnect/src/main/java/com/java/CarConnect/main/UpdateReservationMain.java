package com.java.CarConnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarConnect.dao.IReservationService;

import com.java.CarConnect.dao.ReservationService;

public class UpdateReservationMain {
	public static void main(String[] args)
	{

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter reservation id");
		int i = Integer.parseInt(sc.nextLine());
		System.out.println("Enter status");
		String s=sc.nextLine();

		IReservationService ic=new ReservationService();
		String str;
		try {
			str = ic.updateReservation(i,s);
			System.out.println(str);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
	}
}
