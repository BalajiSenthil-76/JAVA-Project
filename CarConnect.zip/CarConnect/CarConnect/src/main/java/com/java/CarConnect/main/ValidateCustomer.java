package com.java.CarConnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarConnect.exception.AuthenticationException;
import com.java.CarConnect.dao.CustomerService;

public class ValidateCustomer {
	
	public static void main(String[] args) {
	
		String username, password;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter UserName : ");
		username = sc.next();
		
		System.out.println("Enter Password : ");
		password = sc.next();
		
		CustomerService customerService = new CustomerService();
		
		try {
			int count = customerService.authenticateCustomer(username, password);
			
			if(count==1)
			{
				System.out.println("Correct Credentials.");
			}
			else
			{
//				System.out.println("Invalid Credentials.");
				AuthenticationException ae = new AuthenticationException("Invalid Credentails.");
				throw ae;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AuthenticationException ae) {
            System.err.println(ae.getMessage());
        }
		
	}
	
}
