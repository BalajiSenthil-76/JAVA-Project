package com.java.CarConnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarConnect.dao.CustomerService;
import com.java.CarConnect.dao.ICustomerService;
import com.java.CarConnect.model.Customer;

public class DeleteCustomer {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Customer Id : ");
		int customerId = sc.nextInt();
		
		ICustomerService customerService = new CustomerService();
		
		try {
			Customer customer = customerService.getCustomerById(customerId);
			
			if(customer!= null)
			{
				String message = customerService.deleterCustomer(customerId);
				System.out.println(message);
			}
			else
			{
				System.out.println("No matching Records found to delete.");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
