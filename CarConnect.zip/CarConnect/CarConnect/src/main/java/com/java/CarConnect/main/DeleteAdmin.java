package com.java.CarConnect.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.CarConnect.exception.AdminNotFoundException;
import com.java.CarConnect.dao.Admindaoimpl;
import com.java.CarConnect.dao.admindao;
import com.java.CarConnect.model.Admin;

public class DeleteAdmin {
public static void main(String[] args) throws AdminNotFoundException {
	int adminID;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the Admin ID you want to delete:");
	adminID=sc.nextInt();
	
	admindao  dao=new Admindaoimpl();
	try {
		dao.DeleteAdmin(adminID);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
