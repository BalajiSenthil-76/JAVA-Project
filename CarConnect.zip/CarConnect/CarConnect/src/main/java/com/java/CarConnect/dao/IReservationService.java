package com.java.CarConnect.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.CarConnect.model.Reservation;

public interface IReservationService {
public String createReservation(Reservation r) throws ClassNotFoundException,SQLException;
public String cancelReservation(int reservationId) throws ClassNotFoundException,SQLException;
public String updateReservation(int id,String status) throws ClassNotFoundException,SQLException;
public Reservation getReservationById(int id) throws ClassNotFoundException,SQLException;
public List<Reservation> getReservationByCustomerId(int customerId )throws ClassNotFoundException,SQLException;




}

