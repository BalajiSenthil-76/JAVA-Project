package com.java.CarConnect.main;

import java.sql.SQLException;

import java.util.List;

import com.java.CarConnect.dao.Admindaoimpl;
import com.java.CarConnect.dao.admindao;
import com.java.CarConnect.model.Admin;

public class Showadmin {
	public static void main(String[] args) {
		admindao dao=new Admindaoimpl();
		try {
			List<Admin> adminlist=dao.Showadmin();
			for (Admin admin : adminlist) {
				System.out.println(admin);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
